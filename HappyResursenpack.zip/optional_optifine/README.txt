Diese Version ist voll auf Vanilla ausgelegt. Eine separate OptiFine-Erweiterung ist in diesem ZIP nicht enthalten.
