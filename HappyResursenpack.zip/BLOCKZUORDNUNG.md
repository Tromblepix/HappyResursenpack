# Blockzuordnung für die Lobby

| Vermuteter Originalblock | Neue Funktion im Design | Neue Textur | Dateipfad | Mögliche Auswirkung außerhalb der Lobby |
|---|---|---|---|---|
| Polished Granite | Technikboden / Bodenplatten | Dunkle Metallplatten mit Fugen, Schrauben und Warnmarkierung | `assets/minecraft/textures/block/polished_granite.png` | Alle polierten Granitböden im Spiel sehen futuristisch aus |
| Granite | Zentrale Technikplatte / Konsolenplattformen | Kommando-Konsole mit Displays und Touchflächen | `assets/minecraft/textures/block/granite.png` | Normale Granitflächen wirken wie Technikblöcke |
| Sea Lantern | Leuchtende Datenleitung / Energieknoten | Animierte Cyan-Leitung | `assets/minecraft/textures/block/sea_lantern.png` + `.mcmeta` | Alle Seelaternen erhalten den futuristischen Leitungslook |
| Dark Oak Log (Seite) | Wandmodule / Deckenmodule | Dunkle Metallsegmente mit Anzeigen, Lüftung und Technikdetails | `assets/minecraft/textures/block/dark_oak_log.png` | Dunkleichenstämme wirken technisch |
| Jungle Log (Seite) | Universums-Wand / futuristisches Space-Panel | Metallrahmen mit Blick ins Weltall | `assets/minecraft/textures/block/jungle_log.png` | Alle Dschungelstämme an den Seiten wirken wie Weltraum-Fenster |
| Jungle Log (Oben/Unten) | Abschlussfläche des Space-Panels | Technische Abschluss-/Rahmentextur | `assets/minecraft/textures/block/jungle_log_top.png` | Stirnflächen von Dschungelstämmen wirken technisch |
| Dark Oak Log (Oben/Unten) | Deckenpaneele | Metall-Deckensegment mit Lichtstreifen | `assets/minecraft/textures/block/dark_oak_log_top.png` | Stirnflächen von Stämmen wirken wie Deckenmodule |
| Dark Oak Planks | Ergänzende Wand-/Deckenflächen | Passendes dunkles Metallpanel | `assets/minecraft/textures/block/dark_oak_planks.png` | Dunkleichenbretter werden futuristisch |
| Birch Planks | Rückwand-Portale / Docking-Rahmen | Helle Metallfassung mit leuchtender Portfläche | `assets/minecraft/textures/block/birch_planks.png` | Birkenbretter werden technisch |
| Oak Planks | Stege / Kabelbrücken | Metallsteg mit sichtbaren Datenkabeln | `assets/minecraft/textures/block/oak_planks.png` | Eichenbretter werden zu Kabelbrücken |
| Carrot on a Stick + CMD | Hologramm, Konsole, Kabelknoten, Dockingstation, Space-Window | Mehrere Custom Models | `assets/minecraft/models/item/*.json` | Nur Items mit passendem CustomModelData betroffen |
