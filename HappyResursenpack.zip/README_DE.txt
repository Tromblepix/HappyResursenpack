HAPPYRESURSENPACK – RESOURCEPACK (Java 1.21.11 / 1.21.x)
=====================================================================

1. INHALT
---------
Dieses ZIP enthält ein funktionsfähiges Minecraft-Java-Resourcepack für deine Lobby mit folgendem Schwerpunkt:
- futuristische Weltraum-Serverzentrale
- dunkles Metall, Weiß, Silber, Cyan / Eisblau
- animierte Datenleitung
- zentrale Technikplatte / Kommando-Konsole
- Docking-/Teleportplattformen für die drei NPC-Bereiche
- zusätzliche Custom Models für Hologramm, Technik-Konsole, Kabelknoten, Dockingstation und Space-Window

2. INSTALLATION AUF DEM SERVER
------------------------------
1. Die ZIP-Datei nicht entpacken.
2. Auf den Server hochladen oder über eine URL bereitstellen.
3. In `server.properties` eintragen:
   - `resource-pack=<deine direkte ZIP-URL>`
   - `require-resource-pack=true` (optional, wenn du das Pack erzwingen willst)
4. Optional zusätzlich `resource-pack-sha1=<SHA1>` setzen.

SHA-1 der ZIP-Datei:
9ee0f7fd4dd9eb93c558b82c9a429ab498c33ead

3. HINWEIS ZUR VERSION / PACK-FORMAT
-----------------------------------
- Zielversion: Minecraft Java 1.21.11 / 1.21.x
- Eingesetzter `pack_format`: 61
- Zusätzlich wurde `supported_formats` von 34 bis 61 gesetzt, damit das Pack innerhalb der 1.21.x-Reihe toleranter ist.

4. VERWENDETE BLÖCKE IN DER LOBBY
---------------------------------
Empfohlene Blockbasis (wie im Screenshot grob angenommen):
- Polished Granite = Technikboden
- Granite = zentrale Konsole / erhöhte Plattformen
- Sea Lantern = leuchtende Datenleitung
- Jungle Log = Weltraum-/Universums-Wände
- Dark Oak Log / Dark Oak Planks = dunkle Technik-/Deckenmodule
- Birch Planks = Rückwand-Portrahmen
- Oak Planks = Stege / Kabelbrücken zu den NPC-Plattformen

Die vollständige Zuordnung steht in `BLOCKZUORDNUNG.md`.

5. EMPFOHLENER AUFBAU DER LOBBY
-------------------------------
- Den bestehenden Raumaufbau beibehalten.
- Die helle Linie im Boden mit Sea Lanterns aufbauen.
- Die große Vorderplattform aus Granite bauen.
- Die drei hinteren Plattformen ebenfalls aus Granite bauen.
- Die Wege dorthin aus Oak Planks als Kabelbrücken gestalten.
- Die Einfassungen der hellen Rückwand-Öffnungen aus Birch Planks bauen.
- Wände aus Jungle Log setzen, damit die Universums-Panels sichtbar werden.
- Decke weiterhin aus Dark Oak Log bzw. Dark Oak Planks setzen.

6. ZENTRALE TECHNIKPLATTE
-------------------------
Die Granite-Textur wurde als integrierte Technikplatte gestaltet.
Sie enthält optisch:
- großen Hauptbildschirm
- Nebenanzeigen
- Touch-/Tastaturbereich
- Status-LEDs

Wenn du eine noch stärkere Wirkung willst, platziere darüber zusätzliche Item Displays mit CustomModelData 210012 (Technik-Konsole).

7. NPC-PLATTFORMEN
------------------
Die drei hinteren Plattformen funktionieren gestalterisch als Docking-/Teleportstationen.
Empfehlung:
- pro Plattform 1–2 zusätzliche Item Displays mit CMD 210014
- daneben CMD 210013 als Kabel-/Anschlussmodul
- hinter den Plattformen CMD 210015 als Space-Window oder Port-Panel

8. CUSTOMMODEL-DATA-WERTE
-------------------------
Basisitem: `minecraft:carrot_on_a_stick`
- 210011 = Server-Hologramm
- 210012 = Technik-Konsole
- 210013 = Kabel-/Anschlussmodul
- 210014 = NPC-Dockingstation
- 210015 = Space-Window

Beispielbefehle stehen in `BEFEHLE_BEISPIELE.txt`.

9. HOLOGRAMM / SPAWN
--------------------
Setze auf den Spawnpunkt ein Item Display mit CMD 210011, idealerweise leicht über dem Boden schwebend.
Zusätzlich können Sea Lanterns sternförmig oder linienförmig zum Spawn hin führen.

10. TEXTE UND SERVERNAMEN SPÄTER ÄNDERN
---------------------------------------
Die normalen Blocktexturen enthalten bewusst keine fest eingebrannten Servertexte, damit es keine sichtbaren Wiederholungen oder Spiegelungen gibt.
Wenn du echte Servernamen anzeigen willst, nutze:
- Text Display Entities
- Scoreboard-/Hologramm-Plugins
- oder zusätzliche Item Displays / GUI-Lösungen

11. OPTIONALE OPTIFINE-FUNKTIONEN
---------------------------------
Diese Hauptversion ist absichtlich Vanilla-kompatibel.
Im Ordner `optional_optifine` liegt nur ein kurzer Hinweis. Es wurden keine OptiFine-Pflichtfunktionen eingebaut.

12. QUALITÄTSCHECK
------------------
Enthalten:
- `pack.mcmeta`
- `pack.png`
- Texturen
- JSON-Modelle
- Animation (`sea_lantern.png.mcmeta`)
- Dokumentation

13. DATEIEN
-----------
Wichtige Dateien:
- `pack.mcmeta`
- `pack.png`
- `README_DE.txt`
- `BLOCKZUORDNUNG.md`
- `BEFEHLE_BEISPIELE.txt`
- `assets/minecraft/textures/block/...`
- `assets/minecraft/models/item/...`

Viel Spaß mit der Lobby!

13. UPDATE-HINWEIS
------------------
- Zusätzlich wurden jetzt `jungle_log.png` und `jungle_log_top.png` ergänzt.
- Dadurch werden Jungle-Log-Wände als metallisch eingefasste Fenster ins Universum dargestellt.
- Wenn du die Seitenwände im Screenshot aus Jungle Logs gebaut hast, erscheinen sie jetzt als Weltraum-Panels.
